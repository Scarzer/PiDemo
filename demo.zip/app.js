// Socket IO 
var app = require('express')(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server)

// Modules that are come from builtin stuff    
var spawn = require('child_process').spawn,
    exec = require('child_process').exec,
    fs = require('fs'),
    events = require('events').EventEmmiter

// Config file accessing
var config = require('./config'),
    serialSet = config.serial, //Serial Settings
    dbFile = config.logFile,
    hoursBk = config.hoursBack;

    console.log("config: " + JSON.stringify(config));
    console.log("serialSet: " + JSON.stringify(serialSet));
    console.log("dbFile: " + JSON.stringify(dbFile.toString()));

// Serial Port shits
var serialport = require('serialport')
    SerialPort = serialport.SerialPort
    serial = new SerialPort(config.port, {
        baudrate : 115200,
        parser : serialport.parsers.readline('\n')
        });

// Global scope variables 
var clients = 0,
    dataPacket = { /* data packet that will be populated by each serial call */
        type : undefined,  
        time : undefined,   
        board1 : undefined, 
        board2 : undefined, 
        board3 : undefined, 
        board4 : undefined, 
        board5 : undefined, 
        board6 : undefined, 
        board7 : undefined, 
        board8 : undefined
        };

server.listen(80);

// The boilerplate actually works right now. DON'T MODIFY ABOVE HERE!!!!
// --------------------------------------------------------------------




// Useful functions and the body will go right down here! 
// --------------------------------------------------------------------

function gt() {
    // Shamelessly picked from some other code!
    return (new Date()).getTime()-18000000;
}

// --------------------------------------------------------------------
//// Main body of the code is right here now! /////////////////////////
// ---------------------------------------------------------------------

// Express routing and body parsing
//



// Serial communication event handlers RIGHT HERE!!!
// ---------------------------------------------------------------------

serial.on('open', function(){
    console.log('Serial port: ' + config.port + ' was opened');
    serial.on('data', function(data){
        console.log(data.toString());
        var inter = data.toString().split(','); //split the data into a csv string

        // I'm not reading the voltage value. Why not? O.o Must
        // figure this shit out right now!!!
        inter.forEach(function(value, index){
            if(value === 'C'){
                dataPacket['type'] = 'current';
            }

            else if(value === 'V'){
                dataPacket['type'] = 'voltage';
            }

            else if(value === '\n'){
                //This is the end of that string. Ship that shit out?
            }

            else if(index > 8){
                return;
            }
            else{
                dataPacket['board'+index] = value
            }
        })
        console.log(dataPacket)
        dataPacket['time'] = Date.now();
    });
});

serial.on('error', function(err){
    console.log('There was an error: ' + err);
    throw err;
});

